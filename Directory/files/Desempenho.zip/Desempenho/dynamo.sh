#!/system/bin/bash

# Caminhos absolutos dos scripts
CREDITS_SCRIPT="/sdcard/Android/data/com.zenithnexus/files/directory/Desempenho/credits.dy"
FILES_SCRIPT="/sdcard/Android/data/com.zenithnexus/files/directory/Desempenho/functions/script.dy"

# Função para exibir mensagens com delay
function exibir_mensagem {
    echo "$1"
    sleep 1  # Delay de 1 segundo
}

exibir_mensagem ""
exibir_mensagem "--------👨‍🏭 𝗜𝗻𝗶𝗰𝗶𝗮𝗻𝗱𝗼 𝗲𝘅𝗲𝗰𝘂𝘁𝗮𝘃𝗲𝗶𝘀---------"
echo  # Linha em branco para melhor visibilidade

# Verifica se o script de créditos existe
if [ -f "$CREDITS_SCRIPT" ]; then
    /system/bin/sh "$CREDITS_SCRIPT" "/system/bin/bash"
else
    exibir_mensagem "Erro: Script de créditos não encontrado em $CREDITS_SCRIPT"
    exit 1
fi

sleep 1  # Delay de 1 segundo
exibir_mensagem "---------🔎 𝗣𝗿𝗼𝗰𝘂𝗿𝗮𝗻𝗱𝗼 𝗺𝗼𝗱𝘂𝗹𝗼----------"
exibir_mensagem ""

# Verifica se o script de lags existe
if [ -f "$FILES_SCRIPT" ]; then
    /system/bin/sh "$FILES_SCRIPT" "/system/bin/bash"
else
    exibir_mensagem "Erro: 🚨 Script não encontrado."
    exit 1
fi
